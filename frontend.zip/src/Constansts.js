// constants.js

export const API_URL = 'http://localhost:8082/userprofile';
export const JWT_SECRET = 'defaultSecretKeyByITCForDemoPurpose';

export const APP_NAME = 'Culinary Coordinator';
export const TIMEOUT = 5000;
